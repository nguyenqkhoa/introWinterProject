package pkg;

import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class DisplayGrid extends GridPane{
  protected Data data = Data.getInstance();
  public DisplayGrid(){
    char[] Letters = {'A', 'B', 'C','D', 'E', 'F', 'G', 'H', 'I', 'J'};
    for (int i = 1; i<11; i++){
      Label label = new Label ("\n      " + Letters[i-1]);
      this.setConstraints(label,i,0);
      this.getChildren().add(label);
    }

    for (int i = 1; i<11; i++){
      Label label = new Label(String.format("    %d    ",i));
      this.setConstraints(label,0,i);
      this.getChildren().add(label);
    }
    this.refresh();
  }

  public DisplayGrid(int[][] shipList){
    this();
  }

  //"abstract" method
  protected void addInteractible(int colIndex, int rowIndex){}

  public final Rectangle makeColorSquare(Color toFill){
    Rectangle res = new Rectangle(50,50);
    res.setFill(toFill);
    res.setStroke(Color.BLACK);
    return res;
  }

  public void highlight(Color color,int colIndex, int rowIndex){
    this.add(makeColorSquare(color), colIndex, rowIndex);
  }

  public void refresh(){
    for (int i = 0; i<100;i++){
      if (data.player[data.turn].board[i%10][i/10] == -1){
        this.highlight(Color.WHITE,i/10+1,i%10+1);
        this.addInteractible(i/10+1,i%10+1);
      } else {
        this.highlight(Color.BLUE,i/10+1,i%10+1);
      }
      if (data.player[data.turn].sqNotHit.contains(i)
          && data.player[data.enemy].sqHit.contains(i)){
            this.highlight(Color.RED,i%10+1,i/10+1);
        } else if (data.player[data.enemy].sqHit.contains(i)){
          this.highlight(Color.BLACK,i%10+1,i/10+1);
        }
      }
  }


}
