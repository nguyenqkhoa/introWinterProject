package pkg;


import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.control.Label;
import javafx.scene.text.Font;
import javafx.scene.control.TextField;

public class FireWindow extends Pane{
  protected Data data = Data.getInstance();
  protected FireGrid enemy = new FireGrid(){
    @Override
    public void injected(){
      fire.setDisable(false);
      self.refresh();
    }
  };
  protected DisplayGrid self = new DisplayGrid();
  protected Button fire = new Button("Confirm target");
	protected Button nuke = new Button("Nuke");
  private boolean[] nukeUsed = {false, false};

  public FireWindow(){
    VBox full = new VBox();
    HBox grids = new HBox();
    HBox buttons = new HBox();
    full.setSpacing(20);
    grids.setSpacing(20);
    buttons.setSpacing(20);
    grids.getChildren().addAll(self, enemy);
    buttons.getChildren().addAll(fire, nuke);
    full.getChildren().addAll(grids, buttons);
    this.getChildren().addAll(full);
    fire.setDisable(true);
    fire.setOnAction(e->{
      fire.setDisable(true);
      enemy.refresh();
      int sq = -1;
      /*if (data.mode == 2 && data.turn == 1){
        int[] res = data.AI.move(data.player[1], data.player[0]);
        System.out.println("AI:"+res[0] +"-"+ res[1]);
        data.player[1].display();
        sq = res[0]*10+res[1];
      } else {*/
      sq = this.enemy.point[0] + this.enemy.point[1]*10;
      //}
      if (data.player[data.turn].sqHit.contains(sq) || sq < 0 || sq > 99){
        //if making illegal move, gets another turn
        data.switchPlayer();
      } else {
        //otherwise, add new square to list
        data.player[data.turn].sqHit.add(sq);
      }
      data.player[data.turn].display();
      data.player[data.turn].displayEnemy(data.player[data.enemy]);
      if (data.player[data.turn].win(data.player[data.enemy])){
        System.out.println("Game over, " + data.turn + " wins");
        switchScene(3);
      }
      data.switchPlayer();
      nuke.setDisable(nukeUsed[data.turn]);
      /*
      if (data.mode == 2 && data.turn == 1){
        fire.setDisable(false);
        fire.fire();
        self.refresh();
      }
      */
    });

    nuke.setOnAction(e->{
      enemy.refresh();
      int[][] sqs = new int[3][3];
      for (int i = -1; i<=1; i++){
        for (int j = -1; j<=1; j++){
          sqs[i+1][j+1] = (this.enemy.point[0]+i) + (this.enemy.point[1]+j)*10;
        }
      }
      if (data.player[data.turn].sqHit.contains(sqs[1][1])) {
        //do nothing
      } else {
        for (int k = 0; k<9; k++){
          //nuke only needs to clear center for firing
            if (sqs[k/3][k%3] >= 0
                && sqs[k/3][k%3] <= 99){
                data.player[data.turn].sqHit.add(sqs[k/3][k%3]);
                nukeUsed[data.turn] = true;
          }
        }
        if (data.player[data.turn].win(data.player[data.enemy])){
          System.out.println("Game over, " + data.turn + " wins");
          switchScene(3);
        }
        data.switchPlayer();
        nuke.setDisable(nukeUsed[data.turn]);
        fire.setDisable(true);
      }

    });
  }

  public void switchScene(int target){}

  public void refresh(){
    self.refresh();
    enemy.refresh();
  }
}
